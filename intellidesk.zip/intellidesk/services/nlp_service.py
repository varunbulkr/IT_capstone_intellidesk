"""
IntelliDesk NLP Service
HuggingFace zero-shot classification for intent detection
with pre-built knowledge base for automated responses
"""

from typing import Optional, Tuple
from config import settings

# Try to load the real model; fall back to rule-based if unavailable
try:
    from transformers import pipeline
    classifier = pipeline(
        "zero-shot-classification",
        model=settings.NLP_MODEL,
        device=-1  # CPU
    )
    MODEL_LOADED = True
    print(f"[NLP] Model '{settings.NLP_MODEL}' loaded successfully.")
except Exception as e:
    MODEL_LOADED = False
    print(f"[NLP] Could not load HuggingFace model: {e}")
    print("[NLP] Falling back to keyword-based intent detection.")


# Intent categories that map to ticket categories
INTENT_LABELS = [
    "greeting or casual conversation",
    "password reset",
    "network connectivity issue",
    "software installation or update",
    "hardware malfunction",
    "access permission request",
    "general IT inquiry"
]

# Map intents to ticket categories
INTENT_TO_CATEGORY = {
    "greeting or casual conversation": "general",
    "password reset": "password",
    "network connectivity issue": "network",
    "software installation or update": "software",
    "hardware malfunction": "hardware",
    "access permission request": "access",
    "general IT inquiry": "general"
}

# Knowledge base: pre-built troubleshooting responses per intent
KNOWLEDGE_BASE = {
    "greeting or casual conversation": {
        "response": (
            "Hello! I'm your AI IT support assistant. How can I help you today?\n\n"
            "You can ask me about:\n"
            "- Password resets\n"
            "- Network / WiFi issues\n"
            "- Software installation\n"
            "- Hardware problems\n"
            "- Access permissions\n\n"
            "Just describe your issue and I'll do my best to help!"
        ),
        "priority": "low"
    },
    "password reset": {
        "response": (
            "I can help you with your password reset! Here are the steps:\n\n"
            "1. Go to the login page and click 'Forgot Password'\n"
            "2. Enter your registered email address\n"
            "3. Check your inbox for the password reset link (also check spam folder)\n"
            "4. Click the link and set a new password\n"
            "5. Your new password must be at least 8 characters with one uppercase letter and one number\n\n"
            "If you still can't reset your password, the issue may need to be escalated to our IT team."
        ),
        "priority": "low"
    },
    "network connectivity issue": {
        "response": (
            "Let me help you troubleshoot your network connectivity issue:\n\n"
            "1. Check if your Wi-Fi is turned on and connected to the correct network\n"
            "2. Try turning Wi-Fi off and back on\n"
            "3. Restart your device\n"
            "4. If using ethernet, check that the cable is securely plugged in\n"
            "5. Try opening a different website to confirm the issue\n"
            "6. Run the network troubleshooter: Settings > Network & Internet > Network Troubleshooter\n"
            "7. If on VPN, try disconnecting and reconnecting\n\n"
            "If the issue persists after these steps, it may be a server-side problem that needs IT attention."
        ),
        "priority": "medium"
    },
    "software installation or update": {
        "response": (
            "Here's how to handle software installation and update issues:\n\n"
            "1. Make sure you have admin rights on your machine\n"
            "2. Check if there's enough disk space (at least 2GB free recommended)\n"
            "3. Close all other applications before installing\n"
            "4. If updating, try uninstalling the current version first, then reinstalling\n"
            "5. Check if your operating system meets the software's minimum requirements\n"
            "6. Temporarily disable antivirus if it's blocking the installation\n"
            "7. Download the installer again in case the file was corrupted\n\n"
            "If you need specific software that requires an IT-approved license, a ticket will be created."
        ),
        "priority": "medium"
    },
    "hardware malfunction": {
        "response": (
            "I'm sorry to hear about the hardware issue. Here are some initial checks:\n\n"
            "1. Restart your device completely (full shutdown, wait 30 seconds, power on)\n"
            "2. Check all cable connections are secure\n"
            "3. If it's a peripheral (mouse, keyboard, monitor), try a different USB port\n"
            "4. Check if the device appears in Device Manager (Windows) or System Information (Mac)\n"
            "5. Try the device on another computer if possible\n\n"
            "Hardware issues typically require hands-on support. I'll create a ticket for our IT team "
            "to assist you in person."
        ),
        "priority": "high"
    },
    "access permission request": {
        "response": (
            "For access permission requests, here's what you need to know:\n\n"
            "1. Access requests must be approved by your manager or department head\n"
            "2. Please specify: the system/resource you need access to, your role, and business justification\n"
            "3. Standard access requests are processed within 24-48 business hours\n"
            "4. Elevated or admin access requires additional security clearance\n\n"
            "I'll create a ticket for this request so our IT administrators can process it."
        ),
        "priority": "medium"
    },
    "general IT inquiry": {
        "response": (
            "Thank you for reaching out to IT support! I'll do my best to help.\n\n"
            "For general inquiries, here are some helpful resources:\n"
            "- Check our IT Knowledge Base for common solutions\n"
            "- Visit the self-service portal for account management\n"
            "- Review the IT policies page for guidelines\n\n"
            "If your question is specific, please provide more details and I'll try to assist. "
            "Otherwise, I can create a support ticket for you."
        ),
        "priority": "low"
    }
}

# Keywords for fallback rule-based detection
KEYWORD_MAP = {
    "password reset": ["password", "reset", "forgot", "login fail", "can't log in", "locked out", "sign in"],
    "network connectivity issue": ["wifi", "wi-fi", "internet", "network", "connection", "disconnect", "vpn", "ethernet", "slow connection"],
    "software installation or update": ["install", "software", "update", "download", "application", "app", "program", "upgrade", "license"],
    "hardware malfunction": ["hardware", "screen", "monitor", "keyboard", "mouse", "printer", "laptop", "broken", "not working", "crash", "blue screen"],
    "access permission request": ["access", "permission", "role", "admin", "authorize", "restricted", "denied", "can't access"],
    "general IT inquiry": ["help", "question", "how to", "what is", "support", "issue", "problem"]
}


def detect_intent_huggingface(text: str) -> Tuple[str, float]:
    """Use HuggingFace zero-shot classification to detect intent."""
    result = classifier(text, INTENT_LABELS, multi_label=False)
    top_label = result["labels"][0]
    top_score = result["scores"][0]
    return top_label, round(top_score, 4)


def detect_intent_keyword(text: str) -> Tuple[str, float]:
    """Fallback keyword-based intent detection."""
    text_lower = text.lower()
    best_intent = "general IT inquiry"
    best_score = 0.0

    for intent, keywords in KEYWORD_MAP.items():
        matches = sum(1 for kw in keywords if kw in text_lower)
        if matches > 0:
            score = min(0.5 + (matches * 0.15), 0.95)
            if score > best_score:
                best_score = score
                best_intent = intent

    if best_score == 0.0:
        best_score = 0.3

    return best_intent, round(best_score, 4)


def detect_intent(text: str) -> Tuple[str, float]:
    """
    Detect user intent from text input.
    Uses HuggingFace model if available, otherwise falls back to keyword matching.
    """
    if MODEL_LOADED:
        return detect_intent_huggingface(text)
    else:
        return detect_intent_keyword(text)


def get_ai_response(intent: str, confidence: float) -> dict:
    """
    Generate AI response based on detected intent and confidence.
    Returns response text, whether to create a ticket, and suggested priority.
    """
    threshold = settings.CONFIDENCE_THRESHOLD
    kb_entry = KNOWLEDGE_BASE.get(intent, KNOWLEDGE_BASE["general IT inquiry"])

    # Handle greetings - no ticket needed
    if intent == "greeting":
        return {
            "response": (
                "Hello! I'm your AI IT support assistant. How can I help you today?\n\n"
                "You can ask me about:\n"
                "- Password resets\n"
                "- Network / WiFi issues\n"
                "- Software installation\n"
                "- Hardware problems\n"
                "- Access permissions\n\n"
                "Just describe your issue and I'll do my best to help!"
            ),
            "should_create_ticket": False,
            "category": "general",
            "priority": "low",
            "confident": True
        }

    # Always create tickets for hardware issues
    auto_ticket_intents = ["hardware malfunction", "access permission request"]

    # Never create tickets for greetings
    no_ticket_intents = ["greeting or casual conversation"]

    if intent in no_ticket_intents:
        return {
            "response": kb_entry["response"],
            "should_create_ticket": False,
            "category": "general",
            "priority": "low",
            "confident": True
        }

    if confidence >= threshold:
        should_create_ticket = intent in auto_ticket_intents
        return {
            "response": kb_entry["response"],
            "should_create_ticket": should_create_ticket,
            "category": INTENT_TO_CATEGORY.get(intent, "general"),
            "priority": kb_entry["priority"],
            "confident": True
        }
    else:
        # Low confidence - always create a ticket
        return {
            "response": (
                "I'm not fully sure I understood your issue correctly. "
                "To make sure you get the right help, I've created a support ticket for you. "
                "Our IT team will review it and get back to you shortly.\n\n"
                f"What I understood: This might be related to '{intent}' "
                f"(confidence: {int(confidence * 100)}%)."
            ),
            "should_create_ticket": True,
            "category": INTENT_TO_CATEGORY.get(intent, "general"),
            "priority": "medium",
            "confident": False
        }
