"""
IntelliDesk Chat Routes
AI Chatbot interface and processing
"""

from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from config import get_db
from models import User, ChatLog
from auth import get_current_user
from services.nlp_service import detect_intent, get_ai_response
from services.ticket_service import create_ticket

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/chat", response_class=HTMLResponse)
async def chat_page(
    request: Request,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Load chat history for this user
    chat_history = (
        db.query(ChatLog)
        .filter(ChatLog.user_id == user.id)
        .order_by(ChatLog.created_at.desc())
        .limit(50)
        .all()
    )
    chat_history.reverse()

    return templates.TemplateResponse(request, "chat.html", {
        "user": user,
        "chat_history": chat_history
    })


@router.post("/api/chat")
async def process_chat(
    request: Request,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    body = await request.json()
    user_message = body.get("message", "").strip()

    if not user_message:
        return JSONResponse({"error": "Empty message"}, status_code=400)

    # Detect intent
    intent, confidence = detect_intent(user_message)

    # Get AI response based on intent and confidence
    result = get_ai_response(intent, confidence)

    ticket_id = None

    # Create ticket if needed
    if result["should_create_ticket"]:
        ticket = create_ticket(
            db=db,
            user_id=user.id,
            subject=f"[AI Chat] {intent.title()}",
            description=f"User message: {user_message}\n\nDetected intent: {intent}\nConfidence: {confidence}",
            category=result["category"],
            priority=result["priority"]
        )
        ticket_id = ticket.id
        if result["confident"]:
            result["response"] += f"\n\nI've also created ticket #{ticket.id} for our IT team to follow up."
        else:
            result["response"] += f"\n\nTicket #{ticket.id} has been created."

    # Log the chat interaction
    chat_log = ChatLog(
        user_id=user.id,
        user_input=user_message,
        detected_intent=intent,
        confidence_score=confidence,
        ai_response=result["response"],
        ticket_created=ticket_id
    )
    db.add(chat_log)
    db.commit()

    return JSONResponse({
        "response": result["response"],
        "intent": intent,
        "confidence": round(confidence * 100, 1),
        "ticket_id": ticket_id,
        "confident": result["confident"]
    })
