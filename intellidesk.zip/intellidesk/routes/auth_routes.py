"""
IntelliDesk Auth Routes
Login, Register, Logout - both pages and API endpoints
"""

from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from config import get_db
from models import User, UserRole
from auth import hash_password, verify_password, create_access_token, get_current_user_optional

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, user: User = Depends(get_current_user_optional)):
    if user:
        if user.role.value == "admin":
            return RedirectResponse(url="/admin", status_code=303)
        return RedirectResponse(url="/dashboard", status_code=303)
    return templates.TemplateResponse(request, "login.html", {
        "error": None
    })


@router.post("/login")
async def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == email).first()

    if not user or not verify_password(password, user.password_hash):
        return templates.TemplateResponse(request, "login.html", {
            "error": "Invalid email or password"
        })

    token = create_access_token(data={
        "user_id": user.id,
        "email": user.email,
        "role": user.role.value
    })

    if user.role.value == "admin":
        response = RedirectResponse(url="/admin", status_code=303)
    else:
        response = RedirectResponse(url="/dashboard", status_code=303)

    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        max_age=3600,
        samesite="lax"
    )
    return response


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, user: User = Depends(get_current_user_optional)):
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)
    return templates.TemplateResponse(request, "register.html", {
        "error": None
    })


@router.post("/register")
async def register_submit(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_db)
):
    # Validation
    if password != confirm_password:
        return templates.TemplateResponse(request, "register.html", {
            "error": "Passwords do not match"
        })

    if len(password) < 6:
        return templates.TemplateResponse(request, "register.html", {
            "error": "Password must be at least 6 characters"
        })

    existing = db.query(User).filter(User.email == email).first()
    if existing:
        return templates.TemplateResponse(request, "register.html", {
            "error": "An account with this email already exists"
        })

    # Create user
    new_user = User(
        name=name,
        email=email,
        password_hash=hash_password(password),
        role=UserRole.USER
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Auto-login
    token = create_access_token(data={
        "user_id": new_user.id,
        "email": new_user.email,
        "role": new_user.role.value
    })

    response = RedirectResponse(url="/dashboard", status_code=303)
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        max_age=3600,
        samesite="lax"
    )
    return response


@router.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie("access_token")
    return response
